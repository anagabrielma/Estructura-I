﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab2_ArbolBinario.Clase_Nodo
{
    internal  class Nodo<T>
    {
        internal Nodo<T> Izquierda = default(Nodo<T>);
        internal Nodo<T> Derecha;
        internal T dato;
        public Nodo(T dato)
        {
            this.dato = dato;
        }
    }
    internal class Arbol<T> where T: IComparable
    {
        List<T> listaNodo = new List<T>();
        //Nodo<T> Raiz = null;
        
        internal void PreOrden(ref Nodo<T> nodo)
        {
            if(nodo != null )
            {
                listaNodo.Add(nodo.dato);
                PreOrden(ref nodo.Izquierda);
                PreOrden(ref nodo.Derecha);
            }
        }
        internal void InOrden(ref Nodo<T> nodo)
        {
            if(nodo !=null)
            {
                InOrden(ref nodo.Izquierda);
                listaNodo.Add(nodo.dato);
                InOrden(ref nodo.Derecha);
            }
        }
        internal void PostOrden(ref Nodo<T> nodo)
        {
            if(nodo != null)
            {
                PostOrden(ref nodo.Izquierda);
                PostOrden(ref nodo.Derecha);
                listaNodo.Add(nodo.dato);
            }
        }

        internal Nodo<T> BuscaDerecho (ref Nodo<T> nodo)
        {
            if(nodo != null)
            {
                while(nodo.Derecha != null)
                {
                    nodo = nodo.Derecha;
                }
            }
            return (nodo);
        }
        internal Nodo<T> BuscaIzquierda(ref Nodo<T> nodo)
        {
            if (nodo != null)
            {
                while (nodo.Izquierda != null)
                {
                    nodo = nodo.Izquierda;
                }
            }
            return (nodo);
        }

        internal void EliminarNodo(ref Nodo<T> nodo,  T buscar, ref Nodo<T> anterior)
        {
            Nodo<T> aux;
            bool encontrado = false;
            
            if(nodo !=null)
            {
                if(buscar.CompareTo(nodo.dato) == 0)
                {
                    if(nodo.Izquierda == null)
                    {
                        if(nodo.Derecha == null)
                        {
                            nodo = null;
                        }
                        else
                        {
                            if(buscar.CompareTo(anterior.dato) == 1)
                            {
                                anterior.Izquierda = nodo.Derecha;
                            }
                            else
                            {
                                anterior.Derecha = nodo.Derecha;
                            }
                        }
                        
                    }
                    else
                    {
                        if(nodo.Derecha == null)
                        {
                           if(buscar.CompareTo(anterior.dato) == -1)
                           {
                                anterior.Derecha = nodo.Izquierda;
                           }
                           else
                           {
                                anterior.Izquierda = nodo.Izquierda;
                           }
                        }
                        else
                        {
                            if(nodo.Izquierda.Derecha != null)
                            {
                                aux = BuscaDerecho(ref nodo.Izquierda);
                                nodo.dato = aux.dato;
                                aux = null;
                            }
                            else
                            {
                                if(nodo.Derecha.Izquierda != null)
                                {
                                    aux = BuscaIzquierda(ref nodo.Derecha);
                                    nodo.dato = aux.dato;
                                    aux = null;
                                }
                                else
                                {
                                    nodo.dato = nodo.Derecha.dato;
                                    if(nodo.Derecha.Derecha != null)
                                    {
                                        nodo.Derecha = nodo.Derecha.Derecha;
                                    }

                                }
                            }
                        }
                    }
                    encontrado = true;
                }
                else
                {
                    EliminarNodo(ref nodo.Izquierda, buscar, ref nodo);
                    if(!encontrado)
                    {
                        EliminarNodo(ref nodo.Derecha, buscar, ref nodo);
                    }
                }
            }
        }
    }
}