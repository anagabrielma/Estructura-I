﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab2_ArbolBinario.Clase_Nodo;
using Newtonsoft.Json;
using System.IO;
using directorios = System.IO;



namespace Lab2_ArbolBinario.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(HttpPostedFileBase archivo)
        {
            return View();
        }
        public ActionResult CargaJson(HttpPostedFileBase archivo)
        {
            string pathArchivo = string.Empty;
            if (archivo != null)
            {
                string path = Server.MapPath("~/Cargas/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                pathArchivo = path + Path.GetFileName(archivo.FileName);
                string extension = Path.GetExtension(archivo.FileName);
                archivo.SaveAs(pathArchivo);
                Random miRandom = new Random();
                string archivoCsv = directorios.File.ReadAllText(pathArchivo);
                var arbol = JsonConvert.DeserializeObject<Arbol<string>>(archivoCsv);
                var cadena = JsonConvert.SerializeObject(arbol);
                TempData["Arbol"] = cadena;

                
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}